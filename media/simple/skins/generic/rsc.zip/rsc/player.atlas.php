<?php if(isset($_GET['jsonp'])) { echo $_GET['jsonp'].'('; } echo '{"frames": [

{
	"filename": "Button_fsoff.png",
	"frame": {"x":2,"y":2,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "Button_fson.png",
	"frame": {"x":74,"y":2,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "Button_pause.png",
	"frame": {"x":146,"y":2,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "Button_play.png",
	"frame": {"x":2,"y":74,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "Button_reset.png",
	"frame": {"x":74,"y":74,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "Button_vol0.png",
	"frame": {"x":146,"y":74,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "Button_vol100.png",
	"frame": {"x":2,"y":146,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "Button_vol50.png",
	"frame": {"x":74,"y":146,"w":70,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":70,"h":70},
	"sourceSize": {"w":70,"h":70}
},
{
	"filename": "bar_bg_begin.png",
	"frame": {"x":146,"y":146,"w":3,"h":8},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":3,"h":8},
	"sourceSize": {"w":3,"h":8}
},
{
	"filename": "bar_bg_center.png",
	"frame": {"x":151,"y":146,"w":1,"h":9},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":1,"h":9},
	"sourceSize": {"w":1,"h":9}
},
{
	"filename": "bar_bg_end.png",
	"frame": {"x":154,"y":146,"w":3,"h":8},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":3,"h":8},
	"sourceSize": {"w":3,"h":8}
},
{
	"filename": "bar_fg_begin.png",
	"frame": {"x":159,"y":146,"w":3,"h":9},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":3,"h":9},
	"sourceSize": {"w":3,"h":9}
},
{
	"filename": "bar_fg_center.png",
	"frame": {"x":164,"y":146,"w":1,"h":9},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":1,"h":9},
	"sourceSize": {"w":1,"h":9}
},
{
	"filename": "bar_fg_end.png",
	"frame": {"x":167,"y":146,"w":3,"h":9},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":3,"h":9},
	"sourceSize": {"w":3,"h":9}
},
{
	"filename": "seek_btn.png",
	"frame": {"x":172,"y":146,"w":18,"h":17},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":18,"h":17},
	"sourceSize": {"w":18,"h":17}
}],
"meta": {
	"app": "http://www.codeandweb.com/texturepacker ",
	"version": "1.0",
	"image": "player.atlas.png",
	"format": "RGBA8888",
	"size": {"w":256,"h":256},
	"scale": "1",
	"smartupdate": "$TexturePacker:SmartUpdate:1fd4ec7f93129925defa255b24d80b38:1/1$"
}
}
'; if(isset($_GET['jsonp'])) { echo ')'; }